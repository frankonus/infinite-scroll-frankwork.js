Author: Frank van Deursen
Author URL: http://www.iamfrank.eu/
Author Email: me@iamfrank.eu

============ Instruction (when using the demo) ============
1.  Make sure there is a MySQL database or create a new one.
2.  Open the "dbConfig" file and change the $dbHost, $dbUsername, $dbPassword, and $dbName variable's value to your phpMyAdmin details.
3.  Browse the "index.php" file on the browser and try to scroll down. You'll see the data would be loaded from the database automatically.

============ Instruction (when using this framework inside your own project) ============
1.  Make sure there is a MySQL database or create a new one.
2.  Make sure your page is connected to a jQuery script.
3.  Make sure your page is connected to the frankwork.js script.
4.  Copy the "dbConfig" file to your own folder.
5.  Open the "dbConfig" file and change the $dbHost, $dbUsername, $dbPassword, and $dbName variable's value to your phpMyAdmin details.
6.  Include the "dbConfig" file on the page where you want to use this framework. (Remember: Have to be a PHP-file)
7.  Create a parent div for your scroll-loading-posts with the id "fw-post-list". (<div id="fw-post-list">)
8.  Open PHP inside your parent div to load posts from database. Example below ↓
        <?php
            //get rows query
            $query = $db->query("SELECT * FROM dbtable ORDER BY id DESC LIMIT 5");

            if($query->num_rows > 0){ 
                while($row = $query->fetch_assoc()){ 
                    $postID = $row["id"];
        ?>
9.  Create a child div with the class "fw-post-item" and place your PHPdata from the database inside it to create your posts. Example below ↓
        <div class="fw-list-item"><p><?php echo $row["id"]; ?></p></div>
10. Close the php 'while' loop.
11. Close the php 'if' statement.
12. OPTIONAL:

============ May I Help You ===========
If you have any query about this script, send me a comment to my e-mail - me@iamfrank.eu